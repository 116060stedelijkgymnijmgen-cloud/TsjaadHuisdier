﻿using System;
using System.Timers;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Diagnostics;
using System.Media;
using System.Windows.Controls;

namespace ElephantDesktopPet
{
    public partial class MainWindow : Window
    {
        readonly Random rand = new Random();

        bool isSleeping = false;
        bool isPetting = false;

        double posX = 400;
        double posY = 400;
        double velX = 0;
        double velY = 0;

        readonly BitmapImage normalImg = new BitmapImage(new Uri("pack://application:,,,/Tsjaad.png"));
        readonly BitmapImage petImg = new BitmapImage(new Uri("pack://application:,,,/Aai.png"));
        readonly BitmapImage sleepImg = new BitmapImage(new Uri("pack://application:,,,/Slaap.png"));

        readonly SoundPlayer talkSound = new SoundPlayer("Praat.wav");

        Timer talkTimer;
        Timer sleepTimer;
        Timer walkTimer;

        readonly string[] texts =
        {
            "Tsjaad",
            "🐘",
            "Meestergijs is wijs",
            "EUEUEUEU",
            "Ik zuig waterputten leeg",
            "Ik plet toeristen",
            "Ik eet kinderen",
            "Ebola uitbraak in Tsjaad!!!",
            "Tsjaad",
            "Afrikanen berijden mij voor 4 cent per ritje",
            "Meestergijs is de messias",
            "VRROOEEUUJEH",
            "Ik ben olifant!!!",
            "Hallo!! ik eet toeristen!",
            "Ik zuig kinderen op met mijn slurf",
            "Waarom heb je mij gedownload?",
            "Ik werk van 9-5 in een circus",
            "SPEEL TSJAAD TD NU!!!",
            "Tsjaad ster is sneller dan licht",
            "Nijlpaarden zijn zeer heet, net zoals de rest van tsjaad",
            "Hallo!!! Het is momenteel 94 graden celcius in tsjaad!!",
            "Ik val safari auto's aan voor de lol",
            "Ik eet embryo's",
            "OH YEAAHHHHHH",
            "Wat voelt het fijn om een tsjaad olifant te zijn!!!"
        };

        readonly string[] googleTexts =
        {
            "Mag ik nu op computer!??",
            "Ikke internet gebruiken?",
            "Ik wil wat opzoeken!!!",
            "Mag ik wat zoeken op google?"
        };

        readonly string[] links =
        {
            "https://kiwinator89.github.io/Tsjaad-TD/",
            "https://kiwinator89.github.io/FiveNightsAtMeesterGijs/",
            "https://meestergijss.github.io/TsjaadRoyale/"
        };

        readonly string[] searchTerms =
        {
            "Ebola uitbraak Tsjaad",
            "waar koop ik een olifant",
            "Meestergijs",
            "Patrick Schimmel",
            "safari ongeluk olifant",
            "olifant circus ongeluk",
            "nijlpaard aanval",
            "robot leeuwen vs wilde apen",
            "Tsjaad TD beste strategie",
            "olifant vs neushoorn",
            "armoede Afrika",
            "Tsjaadinator atoom raketten",
            "Tsjaad tribale tiran",
            "Tsjaad ster",
            "Olifant VS Mecha hitler",
            "Olifant als huisdier nemen Nederland",
            "Wat is moeilijker Tsjaad modus plus of aangenomen worden bij NASA",
            "Meestergijs google maps",
            "Schimmelpennicklaan 59 Zutphen",
            "Tsjaad Polio vaccins diefstal",
            "Opdroging Tsjaadmeer",
            "giraffe aanval circus"
        };

        public MainWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
            MouseDown += OnClick;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            posX = (SystemParameters.PrimaryScreenWidth - ActualWidth) / 2;
            posY = (SystemParameters.PrimaryScreenHeight - ActualHeight) / 2;
            ApplyPosition();

            Elephant.Source = normalImg;

            StartNewWalk();
            StartWalkTimer();
            StartTalkTimer();
            StartSleepTimer();
        }

        private void StartNewWalk()
        {
            if (rand.NextDouble() < 0.20) { velX = 0; velY = 0; return; }
            double angle = rand.NextDouble() * 2 * Math.PI;
            double speed = rand.Next(1, 4);
            velX = Math.Cos(angle) * speed;
            velY = Math.Sin(angle) * speed;
        }

        private void StartWalkTimer()
        {
            walkTimer = new Timer(50);
            walkTimer.Elapsed += WalkTick;
            walkTimer.Start();
        }

        private void WalkTick(object sender, ElapsedEventArgs e)
        {
            if (isSleeping) { velX = 0; velY = 0; return; }

            Dispatcher.Invoke(() =>
            {
                posX += velX;
                posY += velY;

                double screenW = SystemParameters.PrimaryScreenWidth;
                double screenH = SystemParameters.PrimaryScreenHeight;

                if (posX < 0) { posX = 0; velX = Math.Abs(velX); }
                if (posX > screenW - ActualWidth) { posX = screenW - ActualWidth; velX = -Math.Abs(velX); }
                if (posY < 0) { posY = 0; velY = Math.Abs(velY); }
                if (posY > screenH - ActualHeight) { posY = screenH - ActualHeight; velY = -Math.Abs(velY); }

                ApplyPosition();
            });
        }

        private void StartWalkDirectionTimer()
        {
            var t = new Timer(rand.Next(3000, 8000));
            t.Elapsed += (s, ev) =>
            {
                if (!isSleeping && !isPetting) StartNewWalk();
                t.Stop();
                t.Dispose();
                StartWalkDirectionTimer();
            };
            t.Start();
        }

        private void ApplyPosition()
        {
            Left = posX;
            Top = posY;
        }

        private void StartTalkTimer()
        {
            talkTimer?.Stop();
            talkTimer?.Dispose();
            talkTimer = new Timer(rand.Next(4000, 14000));
            talkTimer.Elapsed += OnTalkTick;
            talkTimer.Start();
            StartWalkDirectionTimer();
        }

        private void OnTalkTick(object sender, ElapsedEventArgs e)
        {
            if (isSleeping || isPetting) return;

            Dispatcher.Invoke(() =>
            {
                double chance = rand.NextDouble();

                if (chance < 0.10)
                {
                    // Bubbel toont alleen de vraag, NIET het zoekwoord of de link
                    string vraag = googleTexts[rand.Next(googleTexts.Length)];
                    string url;

                    if (rand.NextDouble() < 0.5)
                        url = links[rand.Next(links.Length)];
                    else
                    {
                        string zoekwoord = searchTerms[rand.Next(searchTerms.Length)];
                        url = "https://www.google.com/search?q=" + Uri.EscapeDataString(zoekwoord);
                    }

                    BubbleText.Text = vraag;
                    ShowBubble();

                    var result = MessageBox.Show(
                        $"Tsjaad vraagt:\n\n\"{vraag}\"\n\n⚠️ Tsjaad Olifant wil een website openen.\nWat het is? Dat is een verrassing... 🐘",
                        "🐘 Tsjaad wil internet!",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
                        catch { }
                    }
                }
                else
                {
                    BubbleText.Text = texts[rand.Next(texts.Length)];
                    ShowBubble();
                }

                try { talkSound.Play(); } catch { }
            });

            HideBubble(4000);
            StartTalkTimer();
        }

        private void OnClick(object sender, MouseButtonEventArgs e)
        {
            if (isSleeping) return;

            isPetting = true;
            velX = 0;
            velY = 0;

            Dispatcher.Invoke(() =>
            {
                Elephant.Source = petImg;
                BubbleText.Text = "AAHHH YESS Streel mijn huid!!!";
                ShowBubble();
            });

            HideBubble(3000);

            var t = new Timer(2000);
            t.Elapsed += (s, ev) =>
            {
                Dispatcher.Invoke(() =>
                {
                    if (!isSleeping) { Elephant.Source = normalImg; StartNewWalk(); }
                    isPetting = false;
                });
                t.Stop();
                t.Dispose();
            };
            t.Start();
        }

        private void StartSleepTimer()
        {
            sleepTimer = new Timer(rand.Next(30000, 70000));
            sleepTimer.Elapsed += OnSleepTick;
            sleepTimer.Start();
        }

        private void OnSleepTick(object sender, ElapsedEventArgs e)
        {
            sleepTimer.Stop();
            sleepTimer.Dispose();

            Dispatcher.Invoke(() =>
            {
                if (!isSleeping)
                {
                    isSleeping = true;
                    velX = 0;
                    velY = 0;
                    Elephant.Source = sleepImg;
                    BubbleText.Text = "😴 zzz...";
                    ShowBubble();
                    StartWakeTimer();
                }
            });

            HideBubble(3000);
        }

        private void StartWakeTimer()
        {
            var t = new Timer(rand.Next(10000, 20000));
            t.Elapsed += (s, ev) =>
            {
                Dispatcher.Invoke(() =>
                {
                    isSleeping = false;
                    Elephant.Source = normalImg;
                    BubbleText.Text = "👀 ik ben wakker!";
                    ShowBubble();
                    StartNewWalk();
                });

                HideBubble(3000);
                t.Stop();
                t.Dispose();
                StartSleepTimer();
            };
            t.Start();
        }

        private void ShowBubble()
        {
            Bubble.Visibility = Visibility.Visible;
        }

        private void HideBubble(int ms)
        {
            var t = new Timer(ms);
            t.Elapsed += (s, ev) =>
            {
                Dispatcher.Invoke(() => Bubble.Visibility = Visibility.Hidden);
                t.Stop();
                t.Dispose();
            };
            t.Start();
        }
    }
}